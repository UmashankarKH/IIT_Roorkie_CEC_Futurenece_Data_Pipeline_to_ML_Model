SELECT COUNT(*) FROM {table};
